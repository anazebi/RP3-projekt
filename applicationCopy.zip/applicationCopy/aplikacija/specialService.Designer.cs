﻿namespace aplikacija
{
    partial class specialService
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(specialService));
            this.groupBoxSpecial = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxCar = new System.Windows.Forms.TextBox();
            this.checkBoxCar = new System.Windows.Forms.CheckBox();
            this.textBoxBike = new System.Windows.Forms.TextBox();
            this.checkBoxBike = new System.Windows.Forms.CheckBox();
            this.checkBoxDinner = new System.Windows.Forms.CheckBox();
            this.checkBoxLunch = new System.Windows.Forms.CheckBox();
            this.checkBoxBreakfast = new System.Windows.Forms.CheckBox();
            this.textBoxGym = new System.Windows.Forms.TextBox();
            this.checkBoxGym = new System.Windows.Forms.CheckBox();
            this.textBoxMassage = new System.Windows.Forms.TextBox();
            this.checkMassage = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.groupBoxSpecial.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxSpecial
            // 
            this.groupBoxSpecial.BackColor = System.Drawing.Color.Silver;
            this.groupBoxSpecial.Controls.Add(this.label2);
            this.groupBoxSpecial.Controls.Add(this.textBoxCar);
            this.groupBoxSpecial.Controls.Add(this.checkBoxCar);
            this.groupBoxSpecial.Controls.Add(this.textBoxBike);
            this.groupBoxSpecial.Controls.Add(this.checkBoxBike);
            this.groupBoxSpecial.Controls.Add(this.checkBoxDinner);
            this.groupBoxSpecial.Controls.Add(this.checkBoxLunch);
            this.groupBoxSpecial.Controls.Add(this.checkBoxBreakfast);
            this.groupBoxSpecial.Controls.Add(this.textBoxGym);
            this.groupBoxSpecial.Controls.Add(this.checkBoxGym);
            this.groupBoxSpecial.Controls.Add(this.textBoxMassage);
            this.groupBoxSpecial.Controls.Add(this.checkMassage);
            this.groupBoxSpecial.Location = new System.Drawing.Point(46, 86);
            this.groupBoxSpecial.Name = "groupBoxSpecial";
            this.groupBoxSpecial.Size = new System.Drawing.Size(365, 286);
            this.groupBoxSpecial.TabIndex = 0;
            this.groupBoxSpecial.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(150, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(153, 19);
            this.label2.TabIndex = 17;
            this.label2.Text = "Quantity in hours";
            // 
            // textBoxCar
            // 
            this.textBoxCar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.textBoxCar.Location = new System.Drawing.Point(154, 183);
            this.textBoxCar.Name = "textBoxCar";
            this.textBoxCar.Size = new System.Drawing.Size(162, 24);
            this.textBoxCar.TabIndex = 10;
            // 
            // checkBoxCar
            // 
            this.checkBoxCar.AutoSize = true;
            this.checkBoxCar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.checkBoxCar.Location = new System.Drawing.Point(25, 184);
            this.checkBoxCar.Name = "checkBoxCar";
            this.checkBoxCar.Size = new System.Drawing.Size(58, 24);
            this.checkBoxCar.TabIndex = 9;
            this.checkBoxCar.Tag = "400";
            this.checkBoxCar.Text = "Car";
            this.checkBoxCar.UseVisualStyleBackColor = true;
            // 
            // textBoxBike
            // 
            this.textBoxBike.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.textBoxBike.Location = new System.Drawing.Point(154, 137);
            this.textBoxBike.Name = "textBoxBike";
            this.textBoxBike.Size = new System.Drawing.Size(162, 24);
            this.textBoxBike.TabIndex = 8;
            // 
            // checkBoxBike
            // 
            this.checkBoxBike.AutoSize = true;
            this.checkBoxBike.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.checkBoxBike.Location = new System.Drawing.Point(25, 137);
            this.checkBoxBike.Name = "checkBoxBike";
            this.checkBoxBike.Size = new System.Drawing.Size(64, 24);
            this.checkBoxBike.TabIndex = 7;
            this.checkBoxBike.Tag = "20";
            this.checkBoxBike.Text = "Bike";
            this.checkBoxBike.UseVisualStyleBackColor = true;
            // 
            // checkBoxDinner
            // 
            this.checkBoxDinner.AutoSize = true;
            this.checkBoxDinner.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.checkBoxDinner.Location = new System.Drawing.Point(251, 243);
            this.checkBoxDinner.Name = "checkBoxDinner";
            this.checkBoxDinner.Size = new System.Drawing.Size(81, 24);
            this.checkBoxDinner.TabIndex = 6;
            this.checkBoxDinner.Tag = "60";
            this.checkBoxDinner.Text = "Dinner";
            this.checkBoxDinner.UseVisualStyleBackColor = true;
            // 
            // checkBoxLunch
            // 
            this.checkBoxLunch.AutoSize = true;
            this.checkBoxLunch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.checkBoxLunch.Location = new System.Drawing.Point(148, 243);
            this.checkBoxLunch.Name = "checkBoxLunch";
            this.checkBoxLunch.Size = new System.Drawing.Size(77, 24);
            this.checkBoxLunch.TabIndex = 5;
            this.checkBoxLunch.Tag = "50";
            this.checkBoxLunch.Text = "Lunch";
            this.checkBoxLunch.UseVisualStyleBackColor = true;
            // 
            // checkBoxBreakfast
            // 
            this.checkBoxBreakfast.AutoSize = true;
            this.checkBoxBreakfast.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.checkBoxBreakfast.Location = new System.Drawing.Point(25, 243);
            this.checkBoxBreakfast.Name = "checkBoxBreakfast";
            this.checkBoxBreakfast.Size = new System.Drawing.Size(103, 24);
            this.checkBoxBreakfast.TabIndex = 4;
            this.checkBoxBreakfast.Tag = "20";
            this.checkBoxBreakfast.Text = "Breakfast";
            this.checkBoxBreakfast.UseVisualStyleBackColor = true;
            // 
            // textBoxGym
            // 
            this.textBoxGym.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.textBoxGym.Location = new System.Drawing.Point(154, 92);
            this.textBoxGym.Name = "textBoxGym";
            this.textBoxGym.Size = new System.Drawing.Size(162, 24);
            this.textBoxGym.TabIndex = 3;
            // 
            // checkBoxGym
            // 
            this.checkBoxGym.AutoSize = true;
            this.checkBoxGym.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.checkBoxGym.Location = new System.Drawing.Point(25, 91);
            this.checkBoxGym.Name = "checkBoxGym";
            this.checkBoxGym.Size = new System.Drawing.Size(66, 24);
            this.checkBoxGym.TabIndex = 2;
            this.checkBoxGym.Tag = "40";
            this.checkBoxGym.Text = "Gym";
            this.checkBoxGym.UseVisualStyleBackColor = true;
            // 
            // textBoxMassage
            // 
            this.textBoxMassage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.textBoxMassage.Location = new System.Drawing.Point(154, 46);
            this.textBoxMassage.Name = "textBoxMassage";
            this.textBoxMassage.Size = new System.Drawing.Size(162, 24);
            this.textBoxMassage.TabIndex = 1;
            this.textBoxMassage.Text = " ";
            // 
            // checkMassage
            // 
            this.checkMassage.AutoSize = true;
            this.checkMassage.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.checkMassage.Location = new System.Drawing.Point(25, 45);
            this.checkMassage.Name = "checkMassage";
            this.checkMassage.Size = new System.Drawing.Size(99, 24);
            this.checkMassage.TabIndex = 0;
            this.checkMassage.Tag = "50";
            this.checkMassage.Text = "Massage";
            this.checkMassage.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(40, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(215, 32);
            this.label1.TabIndex = 3;
            this.label1.Text = "Select services";
            // 
            // buttonAdd
            // 
            this.buttonAdd.BackColor = System.Drawing.Color.MistyRose;
            this.buttonAdd.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.buttonAdd.Location = new System.Drawing.Point(200, 388);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(211, 49);
            this.buttonAdd.TabIndex = 15;
            this.buttonAdd.Text = "Print receipt";
            this.buttonAdd.UseVisualStyleBackColor = false;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.MistyRose;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.button1.Location = new System.Drawing.Point(374, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(78, 27);
            this.button1.TabIndex = 16;
            this.button1.Text = "close";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // specialService
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.buttonAdd);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBoxSpecial);
            this.Name = "specialService";
            this.Size = new System.Drawing.Size(455, 469);
            this.groupBoxSpecial.ResumeLayout(false);
            this.groupBoxSpecial.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxSpecial;
        private System.Windows.Forms.TextBox textBoxGym;
        private System.Windows.Forms.CheckBox checkBoxGym;
        private System.Windows.Forms.TextBox textBoxMassage;
        private System.Windows.Forms.CheckBox checkMassage;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkBoxBreakfast;
        private System.Windows.Forms.CheckBox checkBoxDinner;
        private System.Windows.Forms.CheckBox checkBoxLunch;
        private System.Windows.Forms.TextBox textBoxCar;
        private System.Windows.Forms.CheckBox checkBoxCar;
        private System.Windows.Forms.TextBox textBoxBike;
        private System.Windows.Forms.CheckBox checkBoxBike;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
    }
}
