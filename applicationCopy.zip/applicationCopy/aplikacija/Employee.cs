﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace aplikacija
{
    public partial class Employee : UserControl
    {
        public Employee()
        {
            InitializeComponent();
        }

        DBfunctions fn = new DBfunctions();
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && comboBox2.SelectedIndex != -1 && comboBox3.SelectedIndex != -1)
            {
                string query;
                if (comboBox2.SelectedIndex == 1 && comboBox1.SelectedIndex != -1)
                {
                    query = "select rooms from Employee where employeeID = '" + Int32.Parse(textBox1.Text) + "'";
                    DataSet ds = fn.getData(query);
                    string sobe = ds.Tables[0].Rows[0][0].ToString();
                    if (sobe == String.Empty)
                    {
                        sobe = comboBox1.SelectedItem.ToString();
                    }
                    else
                    {
                        sobe += ", " + comboBox1.SelectedItem.ToString();
                    }
                    query = "update Employee set responsiblity = '" + comboBox2.SelectedItem.ToString() + "',employeeHours = '" + comboBox3.SelectedItem.ToString() + "', rooms = '" + sobe + "'where employeeID = '" + Int32.Parse(textBox1.Text) + "'";
                }
                else
                {
                    query = "update Employee set responsiblity = '" + comboBox2.SelectedItem + "',employeeHours = '" + comboBox3.SelectedItem + "'where employeeID = '" + Int32.Parse(textBox1.Text) + "'";
                }
                fn.setData(query, "Added!");
                Employee_Load(this, null);
            }
            else
            {
                MessageBox.Show("All fields must be filled!", "Information missing!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex == 1)
            {
                label3.Visible = true;
                comboBox1.Visible = true;
                string query = "select roomNo from Rooms";
                DataSet ds = fn.getData(query);
                for (int i = 0; i < ds.Tables.Count; i++)
                {
                    comboBox1.Items.Add(ds.Tables[0].Rows[i][0].ToString());
                }
            }
            else
            {
                label3.Visible = false;
                comboBox1.Visible = false;
            }
        }

        private void Employee_Load(object sender, EventArgs e)
        {
            string query = "select * from Employee";
            DataSet ds = fn.getData(query);
            dataGridView1.DataSource = ds.Tables[0];
        }
    }
}