﻿using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.ComponentModel;
using System.Data;
using System.Drawing;

namespace aplikacija
{
    public class Receipt
    {
        static int howMany;
        public Dictionary<string,int> Products;
        public int discount = 0;
        public string time = DateTime.Now.ToLongTimeString();
        public string date = DateTime.Now.ToLongDateString();
        public string roomType;
        public int nights;
        public long price;

        static Receipt()
        {
            howMany = 0;
        }

        public int ID { get; }
        public long Overall { get; set; }

        public Receipt(Dictionary<string,int> products)
        {
            this.ID = ++howMany;
            this.Products = new Dictionary<string, int>(products);
        }

        public Receipt(string roomType, int nights, long price)
        {
            this.roomType = roomType;
            this.nights = nights;
            this.price = price;
        }
        public string Total { get { return string.Format("{0}$", Overall); } }

        enum Prices
        {
            Massage = 100,
            Gym = 50,
            Bike = 30,
            Car = 500,
            Breakfast = 30,
            Lunch = 60,
            Dinner = 50
        }
    }
}

