﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aplikacija
{
    public partial class specialService : UserControl
    {
        public specialService()
        {
            InitializeComponent();
        }

        public Receipt rec;

        public event EventHandler<double> serviceAdded;

        enum Prices
        {
            Massage = 100,
            Gym = 50,
            Bike = 30,
            Car = 500,
            Breakfast = 30,
            Lunch = 60,
            Dinner = 50
        }

        int getPrice(string product)
        {
            switch(product)
            {
                case "Massage": 
                    return 100;
                case "Gym": 
                    return 50;
                case "Bike":
                    return 40;
                case "Car":
                    return 500;
                case "Breakfast":
                    return 40;
                case "Lunch":
                    return 60;
                case "Dinner":
                    return 50;
                default:
                    return 0;
            }
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            long sum = 0;
            Dictionary<string, int> products = new Dictionary<string,int>();

            if (checkBoxGym.Checked && textBoxGym.Text != "") 
            {
                sum += (int)Prices.Gym * Convert.ToInt32(textBoxGym.Text);
                products.Add("Gym", Convert.ToInt32(textBoxGym.Text));
            }
            if (checkMassage.Checked && textBoxMassage.Text != "")
            {
                sum += (int)Prices.Massage * Convert.ToInt32(textBoxMassage.Text);
                products.Add("Massage", Convert.ToInt32(textBoxMassage.Text));
            }
            if(checkBoxBike.Checked && textBoxBike.Text != "")
            {
                sum += (int)Prices.Bike * Convert.ToInt32(textBoxBike.Text);
                products.Add("Bike", Convert.ToInt32(textBoxBike.Text));
            }
            if(checkBoxCar.Checked && textBoxCar.Text != "") 
            {
                sum += (int)Prices.Car * Convert.ToInt32(textBoxCar.Text);
                products.Add("Car", Convert.ToInt32(textBoxCar.Text));
            }
            if(checkBoxBreakfast.Checked)
            {
                sum += (int)Prices.Breakfast;
                products.Add("Breakfast", 1);
            }
            if (checkBoxLunch.Checked)
            {
                sum += (int)Prices.Lunch;
                products.Add("Lunch", 1);
            }
            if (checkBoxDinner.Checked)
            {
                sum += (int)Prices.Dinner;
                products.Add("Dinner", 1);
            }
            rec = new Receipt(products);
            if (checkBoxBreakfast.Checked && checkBoxLunch.Checked && checkBoxDinner.Checked)
            {
                sum -= 30;
                rec.discount = 30;
            }
            serviceAdded(this,sum);
            rec.Overall = sum;
            if (printPreviewDialog1.ShowDialog() == DialogResult.OK)
                printDocument1.Print();
            ClearAll();
            Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ClearAll();
            Hide();
        }

        private void ClearAll()
        {
            textBoxBike.Text = "";
            textBoxCar.Text = "";
            textBoxGym.Text = "";
            textBoxMassage.Text = "";
            checkBoxBike.Checked = false;
            checkBoxBreakfast.Checked = false;
            checkBoxCar.Checked = false;
            checkBoxDinner.Checked = false;
            checkBoxGym.Checked = false;
            checkBoxLunch.Checked = false;
            checkMassage.Checked = false;
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString("ReceiptID:     " + rec.ID, DefaultFont, Brushes.Black, new Point(100, 100));
            int i = 1;
            e.Graphics.DrawString("-----------------------------------------------------", DefaultFont, Brushes.Black, new Point(100, 100 + 15 * i));
            i++;
            foreach (KeyValuePair<string,int> pair in rec.Products)
            {

                e.Graphics.DrawString("Product name:     " + pair.Key, DefaultFont, Brushes.Black, new Point(100, 100 + 15*i));
                i++;
                e.Graphics.DrawString("Quantity:     " + (pair.Value).ToString(), DefaultFont, Brushes.Black, new Point(100, 100 + 15*i));
                i++;
                e.Graphics.DrawString("Price:     " + getPrice(pair.Key).ToString() + "$" + " * " + pair.Value.ToString(), DefaultFont, Brushes.Black, new Point(100, 100 + 15*i));
                i++;
            }
            e.Graphics.DrawString("-----------------------------------------------------", DefaultFont, Brushes.Black, new Point(100, 100 + 15 * i));
            i++;
            e.Graphics.DrawString("OVERALL:     " + rec.Overall + "$", DefaultFont, Brushes.Black, new Point(100, 100 + 15 * i));
            i++;
            e.Graphics.DrawString("Date: " + rec.date, DefaultFont, Brushes.Black, new Point(100, 100 + 15 * i));
            i++;
            e.Graphics.DrawString("Time: " + rec.time, DefaultFont, Brushes.Black, new Point(100, 100 + 15 * i));
            i++;
            e.Graphics.DrawString("Discount: " + rec.discount, DefaultFont, Brushes.Black, new Point(100, 100 + 15 * i));
        }
    }
}
