﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Deployment.Application;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aplikacija
{
    public partial class customers : UserControl
    {
        DBfunctions fn = new DBfunctions();
        public event EventHandler<EventArgs> guestChecked;
        string query = "select guestID, guestName, gender, dateIn, dateOut, checkedIn, checkedOut, Guests.roomID, roomNo, roomType, beds, price from Guests, Rooms where Guests.roomID = Rooms.roomID";
        public customers()
        {
            InitializeComponent();
        }

        public void customers_Load(object sender, EventArgs e)
        {
            DataSet ds = fn.getData(query);
            dataGridView1.DataSource = ds.Tables[0];
            dataGridView1.Columns[0].ReadOnly = true;
        }

        private void button4_Click(object sender, EventArgs e) //All
        {
            query = "select guestID, guestName, gender, dateIn, dateOut, checkedIn, checkedOut, Guests.roomID, roomNo, roomType, beds, price from Guests, Rooms where Guests.roomID = Rooms.roomID";
            customers_Load(this, null);
        }

        private void button3_Click(object sender, EventArgs e) // rezervacije
        {
            query = "select guestID, guestName, gender, dateIn, dateOut, checkedIn, checkedOut, Guests.roomID, roomNo, roomType, beds, price from Guests, Rooms where Guests.roomID = Rooms.roomID and checkedOut is null and checkedIn is null";
            customers_Load(this, null);
        }

        private void button1_Click(object sender, EventArgs e) // checkedIn
        {
            query = "select guestID, guestName, gender, dateIn, dateOut, checkedIn, checkedOut, Guests.roomID, roomNo, roomType, beds, price from Guests, Rooms where Guests.roomID = Rooms.roomID and checkedIn = 'YES' and Guests.checkedOut is null";
            customers_Load(this, null);
        }

        private void button2_Click(object sender, EventArgs e) // check in
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in dataGridView1.SelectedRows)
                {
                    int guestID = (int)(row.Cells["guestID"].Value);
                    string dateIn = (string)(row.Cells["dateIn"].Value);
                    string dateNow = DateTime.Now.ToLongDateString();
                    if (dateIn == dateNow)
                        checkIn(guestID);
                    else
                    {
                        MessageBox.Show("Rezervacija vrijedi od " + dateIn);
                        return;
                    }
                }
                guestChecked(this, null);
            }
        }

        void checkIn(int guestid)
        {
            string query = "Update Guests set checkedIn = 'YES' WHERE guestID = " + guestid;
            fn.setData(query, "CHECKED IN");
        }

        void checkOut(int guestid)
        {
            string query = "Update Guests set checkedOut = 'YES' WHERE guestID = " + guestid;
            fn.setData(query, "CHECKED OUT");
        }

        void freeRoom(int roomID)
        {
            string query1 = "update Rooms set booked = NULL where roomID = " + roomID;
            fn.setData(query1, "Room free!");
        }

        private void button5_Click(object sender, EventArgs e) // check out
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in dataGridView1.SelectedRows)
                {
                    int guestID = (int)(row.Cells["guestID"].Value);
                    if (row.Cells["checkedIn"].Value != DBNull.Value)
                    {
                        checkOut(guestID);
                        int roomID = (int)(row.Cells["roomID"].Value);
                        freeRoom(roomID);
                    }
                    else
                    {
                        MessageBox.Show("Can't check out because guest wasn't checked in.", "ERROR");
                        return;
                    }
                }
                guestChecked(this, null);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            query = "select guestID, guestName, gender, dateIn, dateOut, checkedIn, checkedOut, Guests.roomID, roomNo, roomType, beds, price from Guests, Rooms where Guests.roomID = Rooms.roomID and checkedOut = 'YES'";
            customers_Load(this, null);
        }
    }
}
