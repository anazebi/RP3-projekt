﻿namespace aplikacija
{
    partial class specialService
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxSpecial = new System.Windows.Forms.GroupBox();
            this.checkBoxDinner = new System.Windows.Forms.CheckBox();
            this.checkBoxLunch = new System.Windows.Forms.CheckBox();
            this.checkBoxBreakfast = new System.Windows.Forms.CheckBox();
            this.textBoxGym = new System.Windows.Forms.TextBox();
            this.checkBoxGym = new System.Windows.Forms.CheckBox();
            this.textBoxMassage = new System.Windows.Forms.TextBox();
            this.checkMassage = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxCar = new System.Windows.Forms.TextBox();
            this.checkBoxCar = new System.Windows.Forms.CheckBox();
            this.textBoxBike = new System.Windows.Forms.TextBox();
            this.checkBoxBike = new System.Windows.Forms.CheckBox();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBoxSpecial.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxSpecial
            // 
            this.groupBoxSpecial.BackColor = System.Drawing.Color.Silver;
            this.groupBoxSpecial.Controls.Add(this.textBoxCar);
            this.groupBoxSpecial.Controls.Add(this.checkBoxCar);
            this.groupBoxSpecial.Controls.Add(this.textBoxBike);
            this.groupBoxSpecial.Controls.Add(this.checkBoxBike);
            this.groupBoxSpecial.Controls.Add(this.checkBoxDinner);
            this.groupBoxSpecial.Controls.Add(this.checkBoxLunch);
            this.groupBoxSpecial.Controls.Add(this.checkBoxBreakfast);
            this.groupBoxSpecial.Controls.Add(this.textBoxGym);
            this.groupBoxSpecial.Controls.Add(this.checkBoxGym);
            this.groupBoxSpecial.Controls.Add(this.textBoxMassage);
            this.groupBoxSpecial.Controls.Add(this.checkMassage);
            this.groupBoxSpecial.Location = new System.Drawing.Point(46, 86);
            this.groupBoxSpecial.Name = "groupBoxSpecial";
            this.groupBoxSpecial.Size = new System.Drawing.Size(365, 286);
            this.groupBoxSpecial.TabIndex = 0;
            this.groupBoxSpecial.TabStop = false;
            // 
            // checkBoxDinner
            // 
            this.checkBoxDinner.AutoSize = true;
            this.checkBoxDinner.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.checkBoxDinner.Location = new System.Drawing.Point(251, 234);
            this.checkBoxDinner.Name = "checkBoxDinner";
            this.checkBoxDinner.Size = new System.Drawing.Size(81, 24);
            this.checkBoxDinner.TabIndex = 6;
            this.checkBoxDinner.Tag = "60";
            this.checkBoxDinner.Text = "Dinner";
            this.checkBoxDinner.UseVisualStyleBackColor = true;
            // 
            // checkBoxLunch
            // 
            this.checkBoxLunch.AutoSize = true;
            this.checkBoxLunch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.checkBoxLunch.Location = new System.Drawing.Point(148, 234);
            this.checkBoxLunch.Name = "checkBoxLunch";
            this.checkBoxLunch.Size = new System.Drawing.Size(77, 24);
            this.checkBoxLunch.TabIndex = 5;
            this.checkBoxLunch.Tag = "50";
            this.checkBoxLunch.Text = "Lunch";
            this.checkBoxLunch.UseVisualStyleBackColor = true;
            // 
            // checkBoxBreakfast
            // 
            this.checkBoxBreakfast.AutoSize = true;
            this.checkBoxBreakfast.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.checkBoxBreakfast.Location = new System.Drawing.Point(25, 234);
            this.checkBoxBreakfast.Name = "checkBoxBreakfast";
            this.checkBoxBreakfast.Size = new System.Drawing.Size(103, 24);
            this.checkBoxBreakfast.TabIndex = 4;
            this.checkBoxBreakfast.Tag = "20";
            this.checkBoxBreakfast.Text = "Breakfast";
            this.checkBoxBreakfast.UseVisualStyleBackColor = true;
            // 
            // textBoxGym
            // 
            this.textBoxGym.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.textBoxGym.Location = new System.Drawing.Point(154, 83);
            this.textBoxGym.Name = "textBoxGym";
            this.textBoxGym.Size = new System.Drawing.Size(132, 24);
            this.textBoxGym.TabIndex = 3;
            this.textBoxGym.Text = "Quantity in hours";
            // 
            // checkBoxGym
            // 
            this.checkBoxGym.AutoSize = true;
            this.checkBoxGym.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.checkBoxGym.Location = new System.Drawing.Point(25, 82);
            this.checkBoxGym.Name = "checkBoxGym";
            this.checkBoxGym.Size = new System.Drawing.Size(66, 24);
            this.checkBoxGym.TabIndex = 2;
            this.checkBoxGym.Tag = "40";
            this.checkBoxGym.Text = "Gym";
            this.checkBoxGym.UseVisualStyleBackColor = true;
            // 
            // textBoxMassage
            // 
            this.textBoxMassage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.textBoxMassage.Location = new System.Drawing.Point(154, 37);
            this.textBoxMassage.Name = "textBoxMassage";
            this.textBoxMassage.Size = new System.Drawing.Size(132, 24);
            this.textBoxMassage.TabIndex = 1;
            this.textBoxMassage.Text = "Quantity in hours";
            // 
            // checkMassage
            // 
            this.checkMassage.AutoSize = true;
            this.checkMassage.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.checkMassage.Location = new System.Drawing.Point(25, 36);
            this.checkMassage.Name = "checkMassage";
            this.checkMassage.Size = new System.Drawing.Size(99, 24);
            this.checkMassage.TabIndex = 0;
            this.checkMassage.Tag = "50";
            this.checkMassage.Text = "Massage";
            this.checkMassage.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(40, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(215, 32);
            this.label1.TabIndex = 3;
            this.label1.Text = "Select services";
            // 
            // textBoxCar
            // 
            this.textBoxCar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.textBoxCar.Location = new System.Drawing.Point(154, 174);
            this.textBoxCar.Name = "textBoxCar";
            this.textBoxCar.Size = new System.Drawing.Size(132, 24);
            this.textBoxCar.TabIndex = 10;
            this.textBoxCar.Text = "Quantity in days";
            // 
            // checkBoxCar
            // 
            this.checkBoxCar.AutoSize = true;
            this.checkBoxCar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.checkBoxCar.Location = new System.Drawing.Point(25, 175);
            this.checkBoxCar.Name = "checkBoxCar";
            this.checkBoxCar.Size = new System.Drawing.Size(58, 24);
            this.checkBoxCar.TabIndex = 9;
            this.checkBoxCar.Tag = "400";
            this.checkBoxCar.Text = "Car";
            this.checkBoxCar.UseVisualStyleBackColor = true;
            // 
            // textBoxBike
            // 
            this.textBoxBike.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.textBoxBike.Location = new System.Drawing.Point(154, 128);
            this.textBoxBike.Name = "textBoxBike";
            this.textBoxBike.Size = new System.Drawing.Size(132, 24);
            this.textBoxBike.TabIndex = 8;
            this.textBoxBike.Text = "Quantity in hours";
            // 
            // checkBoxBike
            // 
            this.checkBoxBike.AutoSize = true;
            this.checkBoxBike.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.checkBoxBike.Location = new System.Drawing.Point(25, 128);
            this.checkBoxBike.Name = "checkBoxBike";
            this.checkBoxBike.Size = new System.Drawing.Size(64, 24);
            this.checkBoxBike.TabIndex = 7;
            this.checkBoxBike.Tag = "20";
            this.checkBoxBike.Text = "Bike";
            this.checkBoxBike.UseVisualStyleBackColor = true;
            // 
            // buttonAdd
            // 
            this.buttonAdd.BackColor = System.Drawing.Color.MistyRose;
            this.buttonAdd.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.buttonAdd.Location = new System.Drawing.Point(200, 388);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(211, 49);
            this.buttonAdd.TabIndex = 15;
            this.buttonAdd.Text = "Add services";
            this.buttonAdd.UseVisualStyleBackColor = false;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.MistyRose;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.button1.Location = new System.Drawing.Point(374, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(78, 27);
            this.button1.TabIndex = 16;
            this.button1.Text = "close";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // specialService
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.buttonAdd);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBoxSpecial);
            this.Name = "specialService";
            this.Size = new System.Drawing.Size(455, 469);
            this.groupBoxSpecial.ResumeLayout(false);
            this.groupBoxSpecial.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxSpecial;
        private System.Windows.Forms.TextBox textBoxGym;
        private System.Windows.Forms.CheckBox checkBoxGym;
        private System.Windows.Forms.TextBox textBoxMassage;
        private System.Windows.Forms.CheckBox checkMassage;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkBoxBreakfast;
        private System.Windows.Forms.CheckBox checkBoxDinner;
        private System.Windows.Forms.CheckBox checkBoxLunch;
        private System.Windows.Forms.TextBox textBoxCar;
        private System.Windows.Forms.CheckBox checkBoxCar;
        private System.Windows.Forms.TextBox textBoxBike;
        private System.Windows.Forms.CheckBox checkBoxBike;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Button button1;
    }
}
