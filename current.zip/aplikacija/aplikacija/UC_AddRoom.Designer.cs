﻿namespace aplikacija.User_Control
{
    partial class UC_AddRoom
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtRoomNo = new System.Windows.Forms.TextBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.txtRoomType = new System.Windows.Forms.ComboBox();
            this.txtBeds = new System.Windows.Forms.ComboBox();
            this.btnAddRoom = new System.Windows.Forms.Button();
            this.buttonShowFree = new System.Windows.Forms.Button();
            this.buttonShowAll = new System.Windows.Forms.Button();
            this.buttonFilterRooms = new System.Windows.Forms.Button();
            this.labelCapacity = new System.Windows.Forms.Label();
            this.labelBestBuy = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(50, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(245, 40);
            this.label1.TabIndex = 0;
            this.label1.Text = "Room details";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.MistyRose;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(57, 92);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1004, 355);
            this.dataGridView1.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1107, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(176, 28);
            this.label2.TabIndex = 2;
            this.label2.Text = "Room number";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(1107, 320);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 28);
            this.label3.TabIndex = 3;
            this.label3.Text = "Price";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(1107, 243);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 28);
            this.label4.TabIndex = 4;
            this.label4.Text = "Beds";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(1107, 162);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(137, 28);
            this.label5.TabIndex = 5;
            this.label5.Text = "Room type";
            // 
            // txtRoomNo
            // 
            this.txtRoomNo.Location = new System.Drawing.Point(1112, 125);
            this.txtRoomNo.Name = "txtRoomNo";
            this.txtRoomNo.Size = new System.Drawing.Size(266, 22);
            this.txtRoomNo.TabIndex = 6;
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(1112, 361);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(266, 22);
            this.txtPrice.TabIndex = 7;
            // 
            // txtRoomType
            // 
            this.txtRoomType.FormattingEnabled = true;
            this.txtRoomType.Items.AddRange(new object[] {
            "Premium",
            "Classic",
            "Apartman"});
            this.txtRoomType.Location = new System.Drawing.Point(1112, 204);
            this.txtRoomType.Name = "txtRoomType";
            this.txtRoomType.Size = new System.Drawing.Size(266, 24);
            this.txtRoomType.TabIndex = 8;
            // 
            // txtBeds
            // 
            this.txtBeds.FormattingEnabled = true;
            this.txtBeds.Items.AddRange(new object[] {
            "Single",
            "Double",
            "Triple"});
            this.txtBeds.Location = new System.Drawing.Point(1112, 284);
            this.txtBeds.Name = "txtBeds";
            this.txtBeds.Size = new System.Drawing.Size(266, 24);
            this.txtBeds.TabIndex = 9;
            // 
            // btnAddRoom
            // 
            this.btnAddRoom.BackColor = System.Drawing.Color.MistyRose;
            this.btnAddRoom.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F);
            this.btnAddRoom.Location = new System.Drawing.Point(1112, 399);
            this.btnAddRoom.Name = "btnAddRoom";
            this.btnAddRoom.Size = new System.Drawing.Size(100, 49);
            this.btnAddRoom.TabIndex = 10;
            this.btnAddRoom.Text = "Add new room";
            this.btnAddRoom.UseVisualStyleBackColor = false;
            this.btnAddRoom.Click += new System.EventHandler(this.btnAddRoom_Click);
            // 
            // buttonShowFree
            // 
            this.buttonShowFree.BackColor = System.Drawing.Color.MistyRose;
            this.buttonShowFree.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonShowFree.Location = new System.Drawing.Point(812, 37);
            this.buttonShowFree.Name = "buttonShowFree";
            this.buttonShowFree.Size = new System.Drawing.Size(249, 49);
            this.buttonShowFree.TabIndex = 11;
            this.buttonShowFree.Text = "Avalaible rooms";
            this.buttonShowFree.UseVisualStyleBackColor = false;
            this.buttonShowFree.Click += new System.EventHandler(this.buttonShowFree_Click);
            // 
            // buttonShowAll
            // 
            this.buttonShowAll.BackColor = System.Drawing.Color.MistyRose;
            this.buttonShowAll.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonShowAll.Location = new System.Drawing.Point(557, 37);
            this.buttonShowAll.Name = "buttonShowAll";
            this.buttonShowAll.Size = new System.Drawing.Size(249, 49);
            this.buttonShowAll.TabIndex = 12;
            this.buttonShowAll.Text = "All rooms";
            this.buttonShowAll.UseVisualStyleBackColor = false;
            this.buttonShowAll.Click += new System.EventHandler(this.buttonShowAll_Click);
            // 
            // buttonFilterRooms
            // 
            this.buttonFilterRooms.BackColor = System.Drawing.Color.MistyRose;
            this.buttonFilterRooms.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonFilterRooms.Location = new System.Drawing.Point(1222, 399);
            this.buttonFilterRooms.Name = "buttonFilterRooms";
            this.buttonFilterRooms.Size = new System.Drawing.Size(156, 49);
            this.buttonFilterRooms.TabIndex = 13;
            this.buttonFilterRooms.Text = "Filter";
            this.buttonFilterRooms.UseVisualStyleBackColor = false;
            this.buttonFilterRooms.Click += new System.EventHandler(this.buttonFilterRooms_Click);
            // 
            // labelCapacity
            // 
            this.labelCapacity.AutoSize = true;
            this.labelCapacity.Font = new System.Drawing.Font("MS Reference Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.labelCapacity.ForeColor = System.Drawing.Color.Red;
            this.labelCapacity.Location = new System.Drawing.Point(53, 504);
            this.labelCapacity.Name = "labelCapacity";
            this.labelCapacity.Size = new System.Drawing.Size(183, 24);
            this.labelCapacity.TabIndex = 14;
            this.labelCapacity.Text = "FREE CAPACITY:";
            // 
            // labelBestBuy
            // 
            this.labelBestBuy.AutoSize = true;
            this.labelBestBuy.Font = new System.Drawing.Font("MS Reference Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.labelBestBuy.ForeColor = System.Drawing.Color.Red;
            this.labelBestBuy.Location = new System.Drawing.Point(53, 552);
            this.labelBestBuy.Name = "labelBestBuy";
            this.labelBestBuy.Size = new System.Drawing.Size(124, 24);
            this.labelBestBuy.TabIndex = 15;
            this.labelBestBuy.Text = "BEST BUY:";
            // 
            // UC_AddRoom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.labelBestBuy);
            this.Controls.Add(this.labelCapacity);
            this.Controls.Add(this.buttonFilterRooms);
            this.Controls.Add(this.buttonShowAll);
            this.Controls.Add(this.buttonShowFree);
            this.Controls.Add(this.btnAddRoom);
            this.Controls.Add(this.txtBeds);
            this.Controls.Add(this.txtRoomType);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.txtRoomNo);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Name = "UC_AddRoom";
            this.Size = new System.Drawing.Size(1395, 619);
            this.Load += new System.EventHandler(this.UC_AddRoom_Load);
            this.Leave += new System.EventHandler(this.UC_AddRoom_Leave);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtRoomNo;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.ComboBox txtRoomType;
        private System.Windows.Forms.ComboBox txtBeds;
        private System.Windows.Forms.Button btnAddRoom;
        private System.Windows.Forms.Button buttonShowFree;
        private System.Windows.Forms.Button buttonShowAll;
        private System.Windows.Forms.Button buttonFilterRooms;
        private System.Windows.Forms.Label labelCapacity;
        private System.Windows.Forms.Label labelBestBuy;
    }
}
