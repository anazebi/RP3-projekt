﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aplikacija
{
    public partial class specialService : UserControl
    {
        public specialService()
        {
            InitializeComponent();
        }

        public event EventHandler<double> serviceAdded;

        enum Prices
        {
            Massage = 100,
            Gym = 50,
            Bike = 30,
            Car = 500,
            Breakfast = 30,
            Lunch = 60,
            Dinner = 50
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            double sum = 0;

            if (checkBoxGym.Checked) 
            {
                sum += (int)Prices.Gym * Convert.ToInt32(textBoxGym.Text);
            }
            if (checkMassage.Checked)
            {
                sum += (int)Prices.Massage * Convert.ToInt32(textBoxMassage.Text);
            }
            if(checkBoxBike.Checked)
            {
                sum += (int)Prices.Bike * Convert.ToInt32(textBoxBike.Text);
            }
            if(checkBoxCar.Checked) 
            {
                sum += (int)Prices.Car * Convert.ToInt32(textBoxCar.Text);
            }
            if(checkBoxBreakfast.Checked)
            {
                sum += (int)Prices.Breakfast;
            }
            if (checkBoxLunch.Checked)
            {
                sum += (int)Prices.Lunch;
            }
            if (checkBoxDinner.Checked)
            {
                sum += (int)Prices.Dinner;
            }
            if (checkBoxBreakfast.Checked && checkBoxLunch.Checked && checkBoxDinner.Checked)
                sum -= 30;

            serviceAdded(this,sum);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Hide();
        }
    }
}
