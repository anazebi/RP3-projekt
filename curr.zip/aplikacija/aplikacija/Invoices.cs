﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aplikacija
{
    public partial class Invoices : UserControl
    {
        DBfunctions fn = new DBfunctions();
        string query;
        public Invoices()
        {
            InitializeComponent();
            query = "select * from reservations";
            specialServices.serviceAdded += addService;
        }

        public void Invoices_Load(object sender, EventArgs e)
        {
            DataSet ds = fn.getData(query);
            dataGridView1.DataSource = ds.Tables[0];
            dataGridView1.Columns[0].ReadOnly = true;
        }

        private void dataGridView1_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewRow row = dataGridView1.SelectedRows[0];
            DateTime time = DateTime.Now;
            long overall = (long)row.Cells["overall"].Value;
            int resID = (int)row.Cells["reservationID"].Value;

            MessageBox.Show("UKUPNI IZNOS: " + overall + "\n" + 
                "DATUM IZDAVANJA: " + time + "\n"
                 ,"RAČUN ZA REZERVACIJU BROJ: " + resID);
        }

        private void buttonAddSpecial_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                specialServices.Show();
            }
            else
                MessageBox.Show("Select reservation on which you want to add special service.");
        }

        void addService(object sender, double sum)
        {
            DataGridViewRow row = dataGridView1.SelectedRows[0];
            int resid = (int)(row.Cells["reservationID"].Value);
            int amount = (int)sum;
            long overallold = (long)(row.Cells["overall"].Value);
            long overallnew = amount + overallold;
            long specialold = (long)(row.Cells["special"].Value);
            long specialnew = amount + specialold;
            string query = "update Reservations set overall = " + overallnew + ", special = " + specialnew + "where reservationID = " + resid;
            fn.setData(query, "Special services added.");
            Invoices_Load(this, null);
        }

        private void buttonReceipt_Click(object sender, EventArgs e)
        {

        }
    }
}
